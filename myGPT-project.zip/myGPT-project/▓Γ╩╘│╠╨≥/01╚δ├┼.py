import openai
import os


openai.api_key = os.getenv("OPENAI_API_KEY")

result = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role":"user","content":"what is python?"}
    ]
)
print(result)
print(type(result))
print(result["choices"][0]["message"]["content"])