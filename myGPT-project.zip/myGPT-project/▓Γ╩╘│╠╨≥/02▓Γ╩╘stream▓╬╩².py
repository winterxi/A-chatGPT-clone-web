import openai
import os


openai.api_key = os.getenv("OPENAI_API_KEY")

result = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role":"user","content":"what can python apply?"}
    ],
    stream=True
)

for chunk in result:
    # 方法一
    # delta = chunk["choices"][0]["delta"]
    # if "content" in delta:
    #     print(delta["content"],end='')
    # 方法二
    print(chunk["choices"][0]["delta"].get("content",""),end="")
