import openai
import flask
import os

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
openai.api_key = OPENAI_API_KEY

userconfig_json_file = os.getenv("MYGPT_USERCONFIG_FILEPATH")
print(userconfig_json_file)
